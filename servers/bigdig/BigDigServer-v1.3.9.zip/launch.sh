#!/bin/sh
java -Xmx3G -Xms2G -Dfml.core.libraries.mirror="http://mirror.technicpack.net/Technic/lib/fml/%s" -jar BigDig.jar nogui

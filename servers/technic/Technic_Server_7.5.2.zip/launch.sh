#!/bin/sh
java -Xmx3G -Xms2G -jar technic.jar nogui
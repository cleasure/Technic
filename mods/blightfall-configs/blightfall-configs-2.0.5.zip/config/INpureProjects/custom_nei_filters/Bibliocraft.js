if (FML.isModLoaded("BiblioCraft") && Bibliocraft_enabled){
    NEI.override("BiblioCraft:*", [0]);
}

if (FML.isModLoaded("BiblioWoodsNatura") && Bibliocraft_enabled){
    NEI.override("BiblioWoodsNatura:*", [0]);
}
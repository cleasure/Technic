if (FML.isModLoaded("TConstruct") && Tcon_enabled){
    NEI.override("TConstruct:tool*", [0]);
    NEI.override("TConstruct:binding", [0]);
	NEI.override("TConstruct:scytheBlade", [0]);
}

if (FML.isModLoaded("UndergroundBiomes") && Tcon_enabled){
    NEI.override("UndergroundBiomes:igneous_*", [0]);
    NEI.override("UndergroundBiomes:sedimentary_*", [0]);
    NEI.override("UndergroundBiomes:metamorphic_*", [0]);
}

if (FML.isModLoaded("ExtraTiC") && Tcon_enabled)
{
    NEI.override("ExtraTiC:arrowhead", [0]);
    NEI.override("ExtraTiC:axeHead", [0]);
    NEI.override("ExtraTiC:battelSign", [0]);
    NEI.override("ExtraTiC:binding", [0]);
    NEI.override("ExtraTiC:chiselHead", [0]);
    NEI.override("ExtraTiC:chunk", [0]);
    NEI.override("ExtraTiC:crossbar", [0]);
    NEI.override("ExtraTiC:excavatorHead", [0]);
    NEI.override("ExtraTiC:frypanHead", [0]);
    NEI.override("ExtraTiC:fullGuard", [0]);
    NEI.override("ExtraTiC:hammerHead", [0]);
    NEI.override("ExtraTiC:knifeBlade", [0]);
    NEI.override("ExtraTiC:largeGuard", [0]);
    NEI.override("ExtraTiC:largeSwordBlade", [0]);
    NEI.override("ExtraTiC:largeplate", [0]);
    NEI.override("ExtraTiC:lumberaxeHead", [0]);
    NEI.override("ExtraTiC:mediumGuard", [0]);
    NEI.override("ExtraTiC:pickaxeHead", [0]);
    NEI.override("ExtraTiC:scytheHead", [0]);
    NEI.override("ExtraTiC:shovelHead", [0]);
    NEI.override("ExtraTiC:swordBlade", [0]);
    NEI.override("ExtraTiC:toolrod", [0]);
    NEI.override("ExtraTiC:toughbind", [0]);
    NEI.override("ExtraTiC:toughrod", [0]);
}

